/**
 *
 */
package edu.buffalo.ir.project3.index;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

/**
 * @author Chaitanya
 *
 * @created-on Nov 23, 20142:09:22 PM
 *
 */
public class DatasetHTMLMerger {
	public static void main(String[] args) throws IOException {

		File originalDatasetFolder = new File(
				"/Users/Chaitanya/UB Courses/535/Projects/Project_3/Datasets/webpages-dataset-1/webpages-dataset-1/");
		File xmlDatasetFolder = new File(
				"/Users/Chaitanya/UB Courses/535/Projects/Project_3/Datasets/webpages-dataset-1/");

		org.jdom2.Element root = new org.jdom2.Element("root");
		org.jdom2.Document xmlDoc = new org.jdom2.Document(root);

		File xmlFile = new File(xmlDatasetFolder.getAbsolutePath()
				+ File.separatorChar + "Merged.xml");

		for (File file : originalDatasetFolder.listFiles()) {
			try {

				Elements htmlDocElements = Jsoup.parse(file, "UTF-8")
						.getAllElements();

				Elements htmlTag = htmlDocElements.select("html");

				root.addContent(htmlTag.get(0).text());

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// new XMLOutputter().output(doc, System.out);
		XMLOutputter xmlOutput = new XMLOutputter();

		// display nice nice
		xmlOutput.setFormat(Format.getPrettyFormat());
		xmlOutput.output(xmlDoc, new FileWriter(xmlFile));

	}

}