/**
 *
 */
package edu.buffalo.ir.project3.index;

import java.io.File;
import java.io.FileWriter;

import org.jdom2.Attribute;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * @author Chaitanya
 *
 * @created-on Nov 27, 20147:56:47 PM
 *
 */
public class MergeNYTDataset {
	public static void main(String[] args) {

		File originalDatasetFolder = new File(
				"/Users/Chaitanya/UB Courses/535/Projects/Project_3/Datasets/webpages-dataset-1/webpages-dataset-1/");
		File xmlDatasetFolder = new File(
				"/Users/Chaitanya/UB Courses/535/Projects/Project_3/Datasets/webpages-dataset-1/webpages-dataset-1_xml/");
		xmlDatasetFolder.mkdir();
		for (File file : originalDatasetFolder.listFiles()) {
			try {

				File xmlFile = new File(xmlDatasetFolder.getAbsolutePath()
						+ File.separatorChar + file.getName() + ".xml");

				Elements htmlDocElements = Jsoup.parse(file, "UTF-8")
						.getAllElements();

				org.jdom2.Element docTag = new org.jdom2.Element("doc");
				org.jdom2.Element root = new org.jdom2.Element("add");
				org.jdom2.Document xmlDoc = new org.jdom2.Document(root);

				root.addContent(docTag);

				for (Element element : htmlDocElements) {
					if (element.tagName().equals("meta")) {
						String metaContent = element.attr("content");
						String metaName = element.attr("name");

						org.jdom2.Element field = new org.jdom2.Element("field");
						field.setAttribute(new Attribute("name", "meta_"
								+ metaName + "_s"));
						field.addContent(metaContent);
						docTag.addContent(field);

						// System.out.println("meta -> " + metaName
						// + " - " + metaContent);
					}

					if (element.tagName().equals("title")) {
						String titleField = element.text();

						org.jdom2.Element field = new org.jdom2.Element("field");
						field.setAttribute(new Attribute("name", "title"));
						field.addContent(titleField);
						docTag.addContent(field);

						// System.out.println(element.tagName() + " -> " +
						// titleField);
					}
					if (element.tagName().equals("body")) {
						String bodyField = element.text();
						org.jdom2.Element field = new org.jdom2.Element("field");
						field.setAttribute(new Attribute("name", "body"));
						field.addContent(bodyField);
						docTag.addContent(field);

						// System.out.println(element.tagName() + " -> " +
						// bodyField);
						Elements anchors = element.select("a");
						for (Element anchor : anchors) {
							String href = anchor.attr("href");
							if (!href.startsWith("/")
									&& !href.startsWith("?")
									&& !href.startsWith("mailto")
									&& !href.startsWith("javascript")
									&& !href.isEmpty()
									&& !href.startsWith("#")
									&& !href.equalsIgnoreCase("http://www.adobe.com/products/flashplayer/")
									&& href.startsWith("http")) {

								org.jdom2.Element linkField = new org.jdom2.Element(
										"field");
								linkField.setAttribute(new Attribute("name",
										"link_ss"));
								linkField.addContent(href);
								docTag.addContent(linkField);

								// System.out.println("Links in page -> " +
								// href);
							}
						}
					}

				}
				// new XMLOutputter().output(doc, System.out);
				XMLOutputter xmlOutput = new XMLOutputter();

				// display nice nice
				xmlOutput.setFormat(Format.getPrettyFormat());
				xmlOutput.output(xmlDoc, new FileWriter(xmlFile));

				System.out.println(file.getName() + " - Saved!");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}
