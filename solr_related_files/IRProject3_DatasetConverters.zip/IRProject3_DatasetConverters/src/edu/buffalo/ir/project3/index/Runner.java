/**
 *
 */
package edu.buffalo.ir.project3.index;

import java.io.File;
import java.io.FileWriter;

import org.jdom2.Attribute;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

/**
 * @author nikhillo
 *
 */
public class Runner {

	/**
	 *
	 */
	public Runner() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		long start = System.currentTimeMillis();
		File ipDir = new File(
				"/Users/Chaitanya/UB Courses/535/Projects/Project_3/Datasets/reuters_corpus-90_cat/training/");
		File opDir = new File(ipDir + "_xml");
		opDir.mkdir();
		// more? idk!

		String[] files;
		File dir;

		Document d = null;

		try {
			for (File cat : ipDir.listFiles()) {
				dir = new File(cat.getAbsolutePath());
				files = dir.list();

				File opCatDir = new File(opDir + File.separator + cat.getName());
				opCatDir.mkdir();

				if (files == null) {
					continue;
				}

				for (String f : files) {
					try {
						String filename = dir.getAbsolutePath()
								+ File.separator + f;
						d = Parser.parse(filename);

						File xmlFile = new File(opCatDir.getAbsolutePath()
								+ File.separatorChar + f + ".xml");

						org.jdom2.Element docTag = new org.jdom2.Element("doc");
						org.jdom2.Element root = new org.jdom2.Element("add");
						org.jdom2.Document xmlDoc = new org.jdom2.Document(root);
						root.addContent(docTag);
						org.jdom2.Element fieldId = new org.jdom2.Element(
								"field");
						fieldId.setAttribute(new Attribute("name",
								FieldNames.FILEID.toString()));
						fieldId.addContent(d.getField(FieldNames.FILEID)[0]);
						docTag.addContent(fieldId);

						org.jdom2.Element author = new org.jdom2.Element(
								"field");
						author.setAttribute(new Attribute("name",
								FieldNames.AUTHOR.toString()));
						author.addContent(d.getField(FieldNames.AUTHOR) == null ? ""
								: d.getField(FieldNames.AUTHOR)[0]);
						docTag.addContent(author);

						org.jdom2.Element authorOrg = new org.jdom2.Element(
								"field");
						authorOrg.setAttribute(new Attribute("name",
								FieldNames.AUTHORORG.toString()));
						String authorOrgStr = d.getField(FieldNames.AUTHORORG) == null ? ""
								: d.getField(FieldNames.AUTHORORG)[0];
						authorOrg.addContent(authorOrgStr == null ? ""
								: authorOrgStr);
						docTag.addContent(authorOrg);

						org.jdom2.Element category = new org.jdom2.Element(
								"field");
						category.setAttribute(new Attribute("name",
								FieldNames.CATEGORY.toString()));
						String catStr = d.getField(FieldNames.CATEGORY) == null ? ""
								: d.getField(FieldNames.CATEGORY)[0];
						category.addContent(catStr == null ? "" : catStr);
						docTag.addContent(category);

						org.jdom2.Element title = new org.jdom2.Element("field");
						title.setAttribute(new Attribute("name",
								FieldNames.TITLE.toString()));
						String titleStr = d.getField(FieldNames.TITLE) == null ? ""
								: d.getField(FieldNames.TITLE)[0];
						title.addContent(titleStr == null ? "" : titleStr);
						docTag.addContent(title);

						org.jdom2.Element place = new org.jdom2.Element("field");
						place.setAttribute(new Attribute("name",
								FieldNames.PLACE.toString()));
						String placeStr = d.getField(FieldNames.PLACE) == null ? ""
								: d.getField(FieldNames.PLACE)[0];
						place.addContent(placeStr == null ? "" : placeStr);
						docTag.addContent(place);

						org.jdom2.Element newsDate = new org.jdom2.Element(
								"field");
						newsDate.setAttribute(new Attribute("name",
								FieldNames.NEWSDATE.toString()));
						String newsDtStr = d.getField(FieldNames.NEWSDATE) == null ? ""
								: d.getField(FieldNames.NEWSDATE)[0];
						newsDate.addContent(newsDtStr == null ? "" : newsDtStr);
						docTag.addContent(newsDate);

						org.jdom2.Element content = new org.jdom2.Element(
								"field");
						content.setAttribute(new Attribute("name",
								FieldNames.CONTENT.toString()));
						String contentStr = d.getField(FieldNames.CONTENT) == null ? ""
								: d.getField(FieldNames.CONTENT)[0];
						content.addContent(contentStr == null ? "" : contentStr);
						docTag.addContent(content);

						// new XMLOutputter().output(doc, System.out);
						XMLOutputter xmlOutput = new XMLOutputter();

						// display nice nice
						xmlOutput.setFormat(Format.getPrettyFormat());
						xmlOutput.output(xmlDoc, new FileWriter(xmlFile));

						System.out.println(filename + " - Saved!");

					} catch (ParserException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			}
			long end = System.currentTimeMillis();
			System.out.println((end - start) / 1000);
			end = System.currentTimeMillis();
			System.out.println((end - start) / 1000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
